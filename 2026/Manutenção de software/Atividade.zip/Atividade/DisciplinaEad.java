public class DisciplinaEad extends Disciplina {
    public DisciplinaEad(int codigo, String nome, int cargaHoraria) {
        super(codigo, nome, cargaHoraria);
    }

    @Override
    public void prepararOferta(Turma oferta) {
        System.out.println("Disciplina " + getNome() + ": sala AVA criada");
        oferta.definirLocal("AVA - Sala " + getNome());

        System.out.println("Disciplina " + getNome() + ": link liberado");
        System.out.println("Link: https://ava./" + getNome() + ".com.br");
    }
}
