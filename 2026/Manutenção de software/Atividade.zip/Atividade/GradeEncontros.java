import java.util.ArrayList;
import java.util.List;

public class GradeEncontros {
    private final List<Encontro> encontros;

    public GradeEncontros() {
        this.encontros = new ArrayList<>();
    }

    public void adicionarEncontro(String dia, String horario) {
        encontros.add(new Encontro(dia, horario));
    }

    public List<Encontro> getEncontros() {
        return encontros;
    }
}
