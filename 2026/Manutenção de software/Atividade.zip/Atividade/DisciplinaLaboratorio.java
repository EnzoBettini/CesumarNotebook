public class DisciplinaLaboratorio extends Disciplina {

    public DisciplinaLaboratorio(int codigo, String nome, int cargaHoraria) {
        super(codigo, nome, cargaHoraria);
        System.out.println("DisciplinaLaboratorio criada: " + nome);
    }

    @Override
    public void prepararOferta(Turma oferta) {
        System.out.println("Disciplina " + getNome() + ": laboratório reservado");
        oferta.definirLocal("Laboratório 3");

        System.out.println("Disciplina " + getNome() + ": equipamentos reservados (kits, bancadas)");
    }
}