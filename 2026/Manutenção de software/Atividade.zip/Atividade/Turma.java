import java.util.ArrayList;
import java.util.List;

public class Turma {

    private String semestre;
    private int vagas;
    private List<String> horarios;
    private String local;

    public Turma(String semestre, int vagas) {
        this.semestre = semestre;
        this.vagas = vagas;
        this.horarios = new ArrayList<>();
        System.out.println("Oferta criada para o semestre " + semestre);
    }

    public void adicionarHorario(String horario) {
        horarios.add(horario);
        System.out.println("Horário adicionado: " + horario);
    }

    public void reservarSala(String local) {
        this.local = local;
        System.out.println("Local definido: " + local);
    }

    public void definirLocal(String local) {
        reservarSala(local);
    }
}