public class DisciplinaPresencial extends Disciplina {

    private GradeEncontros gradeEncontros;

    public DisciplinaPresencial(int codigo, String nome, int cargaHoraria) {
        super(codigo, nome, cargaHoraria);
        this.gradeEncontros = new GradeEncontros();
        gradeEncontros.adicionarEncontro("Seg", "19:00-20:40");
        gradeEncontros.adicionarEncontro("Quarta", "19:00-20:40");
    }

    @Override
    public void prepararOferta(Turma oferta) {
        reservarSala(oferta);
        aplicarGradeEncontros(oferta);
    }

    private void reservarSala(Turma oferta) {
        System.out.println("Disciplina " + getNome() + ": sala reservada");
        oferta.reservarSala("Sala 204");
    }

    private void aplicarGradeEncontros(Turma oferta) {
        for (Encontro encontro : gradeEncontros.getEncontros()) {
            oferta.adicionarHorario(encontro.toString());
        }
        System.out.println("Disciplina " + getNome() + ": grade de encontros gerada (" + gradeEncontros.getEncontros().size() + " encontros)");
    }
}
