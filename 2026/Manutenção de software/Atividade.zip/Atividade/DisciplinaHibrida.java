public class DisciplinaHibrida extends Disciplina {

    public DisciplinaHibrida(int codigo, String nome, int cargaHoraria) {
        super(codigo, nome, cargaHoraria);
        System.out.println("DisciplinaHibrida criada: " + nome);
    }

    @Override
    public void prepararOferta(Turma oferta) {
        System.out.println("Disciplina " + getNome() + ": sala reservada");
        System.out.println("Disciplina " + getNome() + ": sala AVA criada");

        oferta.definirLocal("Sala 105 + AVA - Sala " + getNome());

        System.out.println("Disciplina " + getNome() + ": grade de encontros gerada");
        oferta.adicionarHorario("Ter 19:00-21:00");
    }
}