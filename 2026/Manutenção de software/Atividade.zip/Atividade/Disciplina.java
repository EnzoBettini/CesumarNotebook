public abstract class Disciplina {
    private int codigo;
    private String nome;
    private int cargaHoraria;

    public Disciplina(int codigo, String nome, int cargaHoraria) {
        this.codigo = codigo;
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
    }

    public String getNome() {
        return nome;
    }

    public abstract void prepararOferta(Turma oferta);
}
