
public class Main {
    public static void main(String[] args) {
        Curso curso = new Curso("Engenharia de Software", 101);

        curso.adicionarDisciplina(new DisciplinaPresencial(1, "Algoritmos", 60));
        curso.adicionarDisciplina(new DisciplinaEad(2, "Requisitos", 60));
        curso.adicionarDisciplina(new DisciplinaHibrida(3, "Arquitetura", 60));
        curso.adicionarDisciplina(new DisciplinaLaboratorio(4, "Redes (Lab)", 60));

        curso.abrirSemestre("2026/1");
    }
}