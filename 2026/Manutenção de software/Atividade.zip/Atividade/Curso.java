import java.util.ArrayList;
import java.util.List;

public class Curso {
    private String nome;
    private int codigo;
    private List<Disciplina> disciplinaList;

    public Curso(String nome, int codigo) {
        this.nome = nome;
        this.codigo = codigo;
        disciplinaList = new ArrayList<>();
    }

    public void adicionarDisciplina(Disciplina disciplina) {
        disciplinaList.add(disciplina);
        System.out.println("Disciplina adicionada ao curso: " + disciplina.getNome());
    }

    public List<Disciplina> getDisciplinaList() {
        return disciplinaList;
    }

    public void abrirSemestre(String semestre) {

        System.out.printf("Semestre %s aberto para o curso %s%n", semestre, this.nome);

        for (Disciplina d : disciplinaList) {
            System.out.println("\n--- Preparando oferta da disciplina: " + d.getNome() + " ---");

            Turma oferta = new Turma(semestre, 40);
            d.prepararOferta(oferta);

            System.out.println("--- Oferta preparada para: " + d.getNome() + " ---");

        }
    }
}