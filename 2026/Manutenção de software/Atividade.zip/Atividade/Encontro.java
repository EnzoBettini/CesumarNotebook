public class Encontro {
    private final String dia;
    private final String horario;

    public Encontro(String dia, String horario) {
        this.dia = dia;
        this.horario = horario;
    }

    @Override
    public String toString() {
        return dia + " " + horario;
    }
}
